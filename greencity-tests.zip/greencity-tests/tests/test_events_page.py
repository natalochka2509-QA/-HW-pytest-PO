import pytest
from src.pages import EventsPage, BasePage
from src.components import Header, FilterPanel, EventCard


@pytest.mark.ui
@pytest.mark.regression
class TestEventsPage:
    """Test Events Page functionality"""
    
    @pytest.fixture(autouse=True)
    def setup(self, setup_teardown):
        """Setup test fixtures"""
        self.driver = setup_teardown
        self.events_page = EventsPage(self.driver)
        self.header = Header(self.driver)
        self.filter_panel = FilterPanel(self.driver)
    
    def test_events_page_loads(self):
        """Test that events page loads successfully"""
        self.events_page.navigate_to_events()
        assert self.events_page.is_events_loaded(), "Events page did not load"
    
    def test_header_is_visible(self):
        """Test that header is visible on events page"""
        self.events_page.navigate_to_events()
        assert self.header.is_header_visible(), "Header is not visible"
    
    def test_events_displayed(self):
        """Test that events are displayed"""
        self.events_page.navigate_to_events()
        events_count = self.events_page.get_events_count()
        assert events_count > 0, "No events found on page"
    
    def test_get_event_titles(self):
        """Test getting event titles"""
        self.events_page.navigate_to_events()
        titles = self.events_page.get_event_titles()
        assert len(titles) > 0, "No event titles found"
        assert all(isinstance(title, str) for title in titles), "Not all titles are strings"
    
    @pytest.mark.smoke
    def test_filter_button_clickable(self):
        """Test that filter button is clickable"""
        self.events_page.navigate_to_events()
        # Click filter button
        self.events_page.click_filter_button()
        # Verify filter panel appears
        assert self.filter_panel.is_filter_panel_visible(), "Filter panel did not appear"
    
    def test_filter_options_exist(self):
        """Test that filter options exist"""
        self.events_page.navigate_to_events()
        self.events_page.click_filter_button()
        options_count = self.filter_panel.get_filter_options_count()
        assert options_count > 0, "No filter options found"
    
    def test_search_functionality(self):
        """Test search in header"""
        self.events_page.navigate_to_events()
        search_query = "workshop"
        self.header.search(search_query)
        # Add assertion based on your actual implementation
        # assert results_found, "No search results found"
